-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: rspade
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_api_keys`
--

DROP TABLE IF EXISTS `_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_api_keys` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_prefix` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_role_id` bigint DEFAULT NULL,
  `last_used_at` timestamp(3) NULL DEFAULT NULL,
  `expires_at` timestamp(3) NULL DEFAULT NULL,
  `is_revoked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `scopes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_api_keys_user_id` (`user_id`),
  KEY `idx_api_keys_key_hash` (`key_hash`),
  KEY `idx_api_keys_key_prefix` (`key_prefix`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_api_keys`
--

LOCK TABLES `_api_keys` WRITE;
/*!40000 ALTER TABLE `_api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `_api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_api_request_log`
--

DROP TABLE IF EXISTS `_api_request_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_api_request_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `api_key_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `site_id` bigint DEFAULT NULL,
  `verb` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` bigint NOT NULL,
  `duration_ms` bigint NOT NULL,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_api_request_log_created_at` (`created_at`),
  KEY `idx_api_request_log_api_key_id` (`api_key_id`),
  KEY `idx_api_request_log_site_id` (`site_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_api_request_log`
--

LOCK TABLES `_api_request_log` WRITE;
/*!40000 ALTER TABLE `_api_request_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `_api_request_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_file_attachments`
--

DROP TABLE IF EXISTS `_file_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_file_attachments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_storage_id` bigint DEFAULT NULL,
  `handler_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handler_ref` json DEFAULT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_extension` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint DEFAULT NULL,
  `file_type_id` bigint DEFAULT NULL,
  `width` bigint DEFAULT NULL COMMENT 'Width in pixels for images/videos',
  `height` bigint DEFAULT NULL COMMENT 'Height in pixels for images/videos',
  `duration` bigint DEFAULT NULL COMMENT 'Duration in seconds for videos/animated images',
  `is_animated` tinyint(1) DEFAULT '0' COMMENT 'Whether this is an animated image (GIF, WebP, APNG)',
  `frame_count` bigint DEFAULT NULL COMMENT 'Number of frames in animated images',
  `preview_unavailable` tinyint(1) NOT NULL DEFAULT '0',
  `fileable_type` bigint DEFAULT NULL,
  `fileable_id` bigint DEFAULT NULL,
  `fileable_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileable_type_meta` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileable_order` bigint DEFAULT NULL,
  `fileable_meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `site_id` bigint NOT NULL,
  `created_by_ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `blob_accessed_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `destroyed_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_files_key` (`key`),
  KEY `idx_files_file_hash_id` (`file_storage_id`),
  KEY `idx_files_site_id` (`site_id`),
  KEY `idx_files_fileable` (`fileable_type`,`fileable_id`),
  KEY `idx_files_file_type_id` (`file_type_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_file_attachments_type_meta` (`fileable_type_meta`),
  KEY `idx_fileable` (`fileable_type`,`fileable_id`),
  KEY `idx_file_attachments_handler_class` (`handler_class`),
  KEY `idx_file_attachments_deleted_at` (`deleted_at`),
  KEY `idx_file_attachments_destroyed_at` (`destroyed_at`),
  CONSTRAINT `_file_attachments_ibfk_1` FOREIGN KEY (`file_storage_id`) REFERENCES `_file_storage` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `_file_attachments_ibfk_2` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_file_attachments`
--

LOCK TABLES `_file_attachments` WRITE;
/*!40000 ALTER TABLE `_file_attachments` DISABLE KEYS */;
INSERT INTO `_file_attachments` VALUES (1,'add69d0180931c3a22abb2639639d873fb2ec85d397e26d29e9accd64cc62b66',1,NULL,NULL,'sample_report.pdf','pdf','application/pdf',304825,6,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-08-24 05:05:42.536','2026-08-24 05:05:42.543',NULL,NULL,NULL,NULL,'2026-08-24 05:05:42.543',NULL,NULL,NULL,NULL),(2,'739bace839c90b4edd7ed280882fd4ce90e88c7d5cb1f3cf8d3165bed4c35717',2,NULL,NULL,'sample_memo.docx','docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document',240329,6,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-08-24 05:05:42.558','2026-08-24 05:05:42.562',NULL,NULL,NULL,NULL,'2026-08-24 05:05:42.561',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `_file_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_file_storage`
--

DROP TABLE IF EXISTS `_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_file_storage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hash` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` bigint NOT NULL,
  `is_indexed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = awaiting extraction cron',
  `render_status_id` bigint NOT NULL DEFAULT '1',
  `rendered_at` timestamp(3) NULL DEFAULT NULL,
  `render_error` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_file_hashes_hash` (`hash`),
  KEY `idx_file_hashes_size` (`size`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_is_indexed` (`is_indexed`),
  KEY `idx_render_status` (`render_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_file_storage`
--

LOCK TABLES `_file_storage` WRITE;
/*!40000 ALTER TABLE `_file_storage` DISABLE KEYS */;
INSERT INTO `_file_storage` VALUES (1,'20f015bada4f451c73fb36111bd523e44218f779f08651797da639fc9c4b63b1',304825,0,1,NULL,NULL,'2026-08-24 05:05:42.505','2026-08-24 05:05:42.505',NULL,NULL,NULL,NULL),(2,'c5da60f328c2b03972141a025b2dfbc4c9da4be0dc1b4e6bc59506fc0afea036',240329,0,2,NULL,NULL,'2026-08-24 05:05:42.550','2026-08-24 05:06:07.514',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_flash_alerts`
--

DROP TABLE IF EXISTS `_flash_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_flash_alerts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` bigint DEFAULT NULL,
  `is_portal` tinyint(1) NOT NULL DEFAULT '0',
  `type_id` bigint NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_session_id` (`session_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `flash_alerts_session_fk` FOREIGN KEY (`session_id`) REFERENCES `_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_flash_alerts`
--

LOCK TABLES `_flash_alerts` WRITE;
/*!40000 ALTER TABLE `_flash_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `_flash_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_login_history`
--

DROP TABLE IF EXISTS `_login_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_login_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `login_user_id` bigint DEFAULT NULL,
  `email_attempted` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_region` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_country` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failure_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `_login_history_login_user_id_idx` (`login_user_id`),
  KEY `_login_history_email_attempted_idx` (`email_attempted`),
  KEY `_login_history_created_at_idx` (`created_at`),
  KEY `_login_history_status_idx` (`status`),
  KEY `_login_history_ip_address_idx` (`ip_address`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_login_history`
--

LOCK TABLES `_login_history` WRITE;
/*!40000 ALTER TABLE `_login_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `_login_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_migrations`
--

DROP TABLE IF EXISTS `_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_migrations`
--

LOCK TABLES `_migrations` WRITE;
/*!40000 ALTER TABLE `_migrations` DISABLE KEYS */;
INSERT INTO `_migrations` VALUES (1,'2024_01_01_000000_create_sessions_table',1),(2,'2025_09_03_054656_create_sites_table',2),(3,'2025_09_03_054826_create_users_table',3),(4,'2025_09_03_054950_create_file_hashes_table',4),(5,'2025_09_03_054950_create_files_table',5),(6,'2025_09_03_054950_create_ip_addresses_table',6),(7,'2025_09_03_054950_create_site_users_table',7),(8,'2025_09_03_054951_create_user_invites_table',8),(9,'2025_09_03_054951_create_user_verifications_table',9),(10,'2025_09_03_152057_create_admin_test_user',10),(11,'2025_09_03_164754_add_rsx_columns_to_sessions_table',11),(12,'2025_09_09_102518_create_flash_alerts_table',12),(13,'2025_09_09_173210_update_flash_alerts_foreign_key_cascade',13),(14,'2025_09_11_235349_fix_flash_alerts_session_id_schema',14),(15,'2025_09_12_185559_add_csrf_token_to_sessions_table',15),(16,'2025_09_16_074547_add_status_to_users_table',16),(17,'2025_09_16_075234_rename_status_column_to_status_id',17),(18,'2025_09_16_075915_create_demo_products_table',18),(19,'2025_09_16_080116_fix_flash_alerts_foreign_key',19),(20,'2025_09_30_023430_drop_and_recreate_session_table',20),(21,'2025_09_30_050004_add_last_login_to_users_table',21),(22,'2025_10_10_021141_create_companies_table',22),(23,'2025_10_10_021204_create_company_departments_table',23),(24,'2025_10_10_021223_create_contacts_table',24),(25,'2025_10_10_021244_add_billing_contact_foreign_key_to_companies',25),(26,'2025_10_14_172351_add_experience_id_to_sessions',26),(27,'2025_10_28_025035_create_projects_table',27),(28,'2025_10_28_025113_create_tasks_table',28),(29,'2025_10_28_043559_create_clients_table',29),(30,'2025_10_28_223500_create_geographic_data_tables',30),(31,'2025_10_29_034934_add_soft_deletes_to_core_tables',31),(32,'2025_11_02_063218_rename_file_tables_for_storage_attachment_refactor',32),(33,'2025_11_02_065329_add_metadata_fields_to_file_attachments',33),(34,'2025_11_02_065347_create_file_thumbnails_table',34),(35,'2025_11_02_070055_create_search_indexes_table',35),(36,'2025_11_02_162826_add_dimensions_to_file_attachments',36),(37,'2025_11_04_011033_add_name_and_phone_columns_to_users_table',37),(38,'2025_11_04_011050_create_user_profiles_table',38),(39,'2025_11_04_014825_add_session_id_to_file_attachments_table',39),(40,'2025_11_04_051746_create_login_users_table',40),(41,'2025_11_04_051828_refactor_site_users_to_users_table',41),(42,'2025_11_04_051907_update_sessions_table_for_login_user_id',42),(43,'2025_11_04_051935_update_user_profiles_foreign_key',43),(44,'2025_11_04_181832_add_invite_columns_to_users_table',44),(45,'2025_11_05_012345_make_login_user_id_nullable_in_users_table',45),(46,'2025_11_13_193740_modify_flash_alerts_table_for_type_based_system',46),(47,'2025_11_16_093331_drop_file_thumbnails_table',47),(48,'2025_11_16_200145_create_tasks_table',48),(49,'2025_11_19_054000_rename_system_tables_to_underscore_prefix',49),(50,'2025_11_19_231708_create_test_user_record',50),(51,'2025_11_21_193529_create_api_keys_table',51),(52,'2025_11_23_160855_create_user_permissions_table',52),(53,'2025_11_23_164439_reindex_user_roles_to_100_based',53),(54,'2025_12_08_042258_drop_migrations_and_rename_sessions_table',54),(55,'2025_12_10_020633_set_user_1_invite_accepted',55),(56,'2025_12_11_050610_create_login_history_table',56),(57,'2025_12_11_061551_create_groups_and_group_users_tables',57),(58,'2025_12_24_210213_add_timezone_to_login_users_table',58),(59,'2025_12_26_023543_convert_client_status_to_enum',59),(60,'2025_12_27_225200_create_type_refs_table',60),(61,'2025_12_27_225224_convert_polymorphic_columns_to_type_refs',61),(62,'2025_12_27_225305_convert_tasks_polymorphic_to_type_refs',62),(63,'2026_01_12_073624_add_timezone_to_sites_table',63),(64,'2026_01_29_070242_create_action_logs_tables',64),(65,'2026_01_29_081808_create_throttle_table',65),(66,'2026_01_29_081902_create_notifications_table',66),(67,'2026_01_29_180540_create_portal_users_table',67),(68,'2026_01_29_180545_create_portal_invitations_table',68),(69,'2026_01_29_180545_create_portal_sessions_table',69),(70,'2026_01_29_184331_create_portal_password_resets_table',70),(71,'2026_04_07_214645_add_contact_id_to_portal_users_table',71),(72,'2026_04_07_234811_add_portal_fields_to_clients_table',72),(73,'2026_04_07_234812_create_portal_memberships_table',73),(74,'2026_04_07_234812_create_shared_items_table',74),(75,'2026_04_08_060108_create_portal_projects_table',75),(76,'2026_04_08_070914_create_email_queue_table',76),(77,'2026_04_08_070914_create_email_recipients_table',77),(78,'2026_06_22_054710_create_settings_tables',78),(79,'2026_06_23_035931_create_portal_notifications_table',79),(80,'2026_06_23_153413_create_announcements_table',80),(81,'2026_06_24_074233_create_portal_requests_table',81),(82,'2026_06_25_154452_create_portal_request_thread_tables',82),(83,'2026_06_25_163348_drop_portal_requests_table',83),(84,'2026_06_30_071030_create_parties_tables',84),(85,'2026_06_30_162814_add_impersonation_to_portal_sessions',85),(86,'2026_07_01_080525_add_status_to_portal_invitations',86),(87,'2026_07_01_132114_create_sms_queue_table',87),(88,'2026_07_01_133258_create_sms_recipients_table',88),(89,'2026_07_02_094505_add_external_handler_fields_to_file_attachments',89),(90,'2026_07_08_084412_add_cron_expression_to_tasks',90),(91,'2026_07_09_084211_add_impersonation_columns_to_sessions',91),(92,'2026_07_13_090000_task_management_hierarchy_schema',92),(93,'2026_07_16_130944_alter_search_indexes_add_extraction_status',93),(94,'2026_07_16_130948_alter_file_storage_add_is_indexed',94),(95,'2026_07_16_143236_add_retention_columns_to_file_attachments',95),(96,'2026_07_16_143237_import_sample_documents',96),(97,'2026_07_22_144452_add_scopes_to_api_keys',97),(98,'2026_07_22_144455_create_api_request_log_table',98),(99,'2026_07_23_135833_create_zip_download_requests_table',99),(100,'2026_07_28_135157_repair_document_mime_routing',100),(101,'2026_07_30_121017_seed_default_site',101),(102,'2026_07_30_152852_drop_language_from_search_indexes',102),(103,'2026_07_31_133354_add_status_reason_to_tasks',103),(104,'2026_08_03_141649_add_preview_unavailable_to_file_attachments',104),(105,'2026_08_07_152553_add_type_to_sessions',105),(106,'2026_08_07_152935_add_type_to_portal_sessions',106),(107,'2026_08_09_053054_drop_session_id_add_ip_to_file_attachments',107),(108,'2026_08_09_075941_merge_portal_sessions_into_sessions',108),(109,'2026_08_09_103324_rename_audit_columns_to_pair_shape',109),(110,'2026_08_09_112232_add_deleted_at_to_actor_tables',110),(111,'2026_08_09_120837_rename_deleted_by_to_pair_shape',111),(112,'2026_08_10_052037_drop_experience_id_add_portal_site_to_sessions',112),(113,'2026_08_10_062042_add_is_portal_to_flash_alerts',113),(114,'2026_08_12_125303_add_failure_tracking_to_tasks',114),(115,'2026_08_13_161806_drop_user_role_id_from_users_table',115),(116,'2026_08_18_081308_cleanup_retired_portal_request_type_ref',116),(117,'2026_08_18_145643_add_timezone_auto_to_login_users_table',117),(118,'2026_08_22_090059_add_render_status_to_file_storage',118);
/*!40000 ALTER TABLE `_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_search_indexes`
--

DROP TABLE IF EXISTS `_search_indexes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_search_indexes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `indexable_type` bigint NOT NULL,
  `indexable_id` bigint NOT NULL,
  `status_id` bigint NOT NULL DEFAULT '1',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `metadata` json DEFAULT NULL,
  `indexed_at` timestamp(3) NULL DEFAULT NULL,
  `extraction_method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `extractor_version` bigint NOT NULL DEFAULT '1',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_indexable` (`indexable_type`,`indexable_id`),
  KEY `idx_indexed_at` (`indexed_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_indexable` (`indexable_type`,`indexable_id`),
  KEY `idx_status` (`status_id`),
  KEY `idx_extractor_version` (`extractor_version`),
  FULLTEXT KEY `ft_content` (`content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_search_indexes`
--

LOCK TABLES `_search_indexes` WRITE;
/*!40000 ALTER TABLE `_search_indexes` DISABLE KEYS */;
/*!40000 ALTER TABLE `_search_indexes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_sessions`
--

DROP TABLE IF EXISTS `_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `site_id` bigint DEFAULT '0',
  `type_id` bigint NOT NULL DEFAULT '1',
  `login_user_id` bigint DEFAULT NULL,
  `portal_user_id` bigint DEFAULT NULL,
  `portal_site_id` bigint DEFAULT NULL,
  `impersonator_login_user_id` bigint DEFAULT NULL,
  `impersonator_user_id` bigint DEFAULT NULL,
  `impersonation_started_at` timestamp(3) NULL DEFAULT NULL,
  `session_token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `csrf_token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handoff_token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handoff_expires_at` timestamp(3) NULL DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_active` datetime(3) NOT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_session_token_unique` (`session_token`),
  KEY `sessions_active_index` (`active`),
  KEY `sessions_last_active_index` (`last_active`),
  KEY `sessions_active_last_active_index` (`active`,`last_active`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_sessions_type_last_active` (`type_id`,`last_active`),
  KEY `idx_sessions_user_active_recent` (`login_user_id`,`active`,`last_active`),
  KEY `idx_sessions_portal_user_recent` (`portal_user_id`,`last_active`),
  KEY `idx_sessions_handoff` (`handoff_token`),
  CONSTRAINT `sessions_portal_user_fk` FOREIGN KEY (`portal_user_id`) REFERENCES `portal_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_sessions`
--

LOCK TABLES `_sessions` WRITE;
/*!40000 ALTER TABLE `_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_setting_values`
--

DROP TABLE IF EXISTS `_setting_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_setting_values` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `setting_id` bigint NOT NULL,
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '0 = global value',
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_setting_site` (`setting_id`,`site_id`),
  KEY `idx_setting_id` (`setting_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_setting_values`
--

LOCK TABLES `_setting_values` WRITE;
/*!40000 ALTER TABLE `_setting_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `_setting_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_settings`
--

DROP TABLE IF EXISTS `_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_settings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Machine identifier, e.g. billing_dow_cutoff',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Human-readable name',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `scope_id` bigint NOT NULL DEFAULT '1' COMMENT '1=global, 2=site',
  `type_id` bigint NOT NULL DEFAULT '1' COMMENT '1=LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci 2=BIGINT 3=decimal 4=DOUBLE 5=boolean 6=date 7=DATETIME(3) 8=json',
  `default_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Serialized default value',
  `meta` json DEFAULT NULL COMMENT 'Type-specific config (e.g. decimal scale)',
  `is_secret` tinyint(1) NOT NULL DEFAULT '0',
  `setting_group` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Optional UI grouping',
  `sort_order` bigint NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_setting_key` (`setting_key`),
  KEY `idx_setting_group` (`setting_group`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_settings`
--

LOCK TABLES `_settings` WRITE;
/*!40000 ALTER TABLE `_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_tasks`
--

DROP TABLE IF EXISTS `_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Fully qualified class name',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Static method name to execute',
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default' COMMENT 'Queue name for concurrency control',
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT 'pending, running, completed, failed, stuck',
  `params` json DEFAULT NULL COMMENT 'Serialized task parameters',
  `result` json DEFAULT NULL COMMENT 'Task result data',
  `logs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Accumulated log messages',
  `error` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Error message if task failed',
  `status_reason` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Human explanation for a terminal/recycled status transition (e.g. KILLED reason)',
  `consecutive_failures` bigint NOT NULL DEFAULT '0' COMMENT 'Runs failed in a row; reset to 0 on success. Nonzero on a cron tracker = a schedule that keeps failing.',
  `scheduled_for` datetime(3) DEFAULT NULL COMMENT 'When task should execute (NULL = ASAP)',
  `next_run_at` datetime(3) DEFAULT NULL COMMENT 'Next run time for recurring scheduled tasks',
  `cron_expression` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Cron expression for recurring scheduled tracker rows (NULL otherwise)',
  `started_at` datetime(3) DEFAULT NULL COMMENT 'When task execution began',
  `completed_at` datetime(3) DEFAULT NULL COMMENT 'When task finished (success or failure)',
  `last_error_at` timestamp(3) NULL DEFAULT NULL COMMENT 'When the most recent failure was recorded (a recycled cron tracker has no completed_at to date it).',
  `last_heartbeat_at` datetime(3) DEFAULT NULL COMMENT 'Last heartbeat from worker process',
  `timeout` bigint DEFAULT NULL COMMENT 'Maximum execution time in seconds (NULL = use default)',
  `worker_pid` bigint DEFAULT NULL COMMENT 'Process ID of worker executing this task',
  `lock_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'MySQL advisory lock key for this task',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_queue` (`queue`),
  KEY `idx_scheduled_for` (`scheduled_for`),
  KEY `idx_next_run_at` (`next_run_at`),
  KEY `idx_worker_pid` (`worker_pid`),
  KEY `idx_status_queue` (`status`,`queue`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_tasks`
--

LOCK TABLES `_tasks` WRITE;
/*!40000 ALTER TABLE `_tasks` DISABLE KEYS */;
INSERT INTO `_tasks` VALUES (1,'App\\RSpade\\Core\\Files\\Document_Render_Service','render_pending','default','pending','[]',NULL,NULL,NULL,NULL,0,'2026-08-24 05:05:42.525',NULL,NULL,NULL,NULL,NULL,NULL,1800,NULL,'rsxtask_run_956e5ab8db2973fbc97f743598fe9737','2026-08-24 05:05:42.525','2026-08-24 05:05:42.525',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_throttle`
--

DROP TABLE IF EXISTS `_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_throttle` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `action_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_executed_at` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_throttle_site_user_action` (`site_id`,`user_id`,`action_key`),
  KEY `idx_throttle_last_executed` (`last_executed_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_throttle`
--

LOCK TABLES `_throttle` WRITE;
/*!40000 ALTER TABLE `_throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_type_refs`
--

DROP TABLE IF EXISTS `_type_refs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_type_refs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_class_name` (`class_name`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_type_refs`
--

LOCK TABLES `_type_refs` WRITE;
/*!40000 ALTER TABLE `_type_refs` DISABLE KEYS */;
/*!40000 ALTER TABLE `_type_refs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_zip_download_requests`
--

DROP TABLE IF EXISTS `_zip_download_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_zip_download_requests` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `download_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `files` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_zip_download_requests_download_key` (`download_key`),
  KEY `idx_zip_download_requests_created_at` (`created_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_zip_download_requests`
--

LOCK TABLES `_zip_download_requests` WRITE;
/*!40000 ALTER TABLE `_zip_download_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `_zip_download_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `action_log_related`
--

DROP TABLE IF EXISTS `action_log_related`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_log_related` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action_log_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  `related_type` bigint NOT NULL,
  `related_id` bigint NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_alr_action_log_id` (`action_log_id`),
  KEY `idx_alr_related` (`related_type`,`related_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `action_log_related_ibfk_1` FOREIGN KEY (`action_log_id`) REFERENCES `action_logs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_log_related`
--

LOCK TABLES `action_log_related` WRITE;
/*!40000 ALTER TABLE `action_log_related` DISABLE KEYS */;
/*!40000 ALTER TABLE `action_log_related` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `action_logs`
--

DROP TABLE IF EXISTS `action_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `type_id` bigint NOT NULL,
  `actor_type` bigint DEFAULT NULL,
  `actor_id` bigint DEFAULT NULL,
  `subject_type` bigint NOT NULL,
  `subject_id` bigint NOT NULL,
  `metadata` json DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_action_logs_site_id` (`site_id`),
  KEY `idx_action_logs_type_id` (`type_id`),
  KEY `idx_action_logs_actor` (`actor_type`,`actor_id`),
  KEY `idx_action_logs_subject` (`subject_type`,`subject_id`),
  KEY `idx_action_logs_created_at` (`created_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_logs`
--

LOCK TABLES `action_logs` WRITE;
/*!40000 ALTER TABLE `action_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `action_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `client_id` bigint DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_at` timestamp(3) NULL DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_announcements_site_client` (`site_id`,`client_id`),
  KEY `idx_announcements_published` (`site_id`,`published_at`),
  KEY `fk_announcements_client_id` (`client_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_announcements_client_id` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_departments`
--

DROP TABLE IF EXISTS `client_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_departments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `client_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_name` (`name`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_client_departments_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_departments`
--

LOCK TABLES `client_departments` WRITE;
/*!40000 ALTER TABLE `client_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_secondary` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_contact_id` bigint DEFAULT NULL,
  `priority` bigint NOT NULL DEFAULT '2',
  `notes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `owner_user_id` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'renamed from address',
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'USA',
  `industry` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_size` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '1-10, 11-50, 51-200, 201-500, 501-1000, 1000+',
  `established_year` bigint DEFAULT NULL,
  `revenue_range` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_handle` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram_handle` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `status_id` bigint NOT NULL DEFAULT '1',
  `preferred_contact_method` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'email' COMMENT 'email, phone, LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci, any',
  `newsletter_opt_in` tinyint(1) NOT NULL DEFAULT '0',
  `portal_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `portal_last_activity_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_name` (`name`),
  KEY `idx_created_by_user_id` (`created_by_id`),
  KEY `idx_owner_user_id` (`owner_user_id`),
  KEY `idx_billing_contact_id` (`billing_contact_id`),
  KEY `idx_priority` (`priority`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_email` (`email`),
  KEY `idx_deleted_at` (`deleted_at`),
  KEY `idx_status_id` (`status_id`),
  KEY `idx_clients_portal_enabled` (`portal_enabled`),
  CONSTRAINT `fk_clients_billing_contact` FOREIGN KEY (`billing_contact_id`) REFERENCES `contacts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `client_id` bigint NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_department_id` bigint DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_secondary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_work` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_cell` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_other` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reports_to_contact_id` bigint DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `priority` bigint NOT NULL DEFAULT '2',
  `notes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `owner_user_id` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_first_name` (`first_name`),
  KEY `idx_last_name` (`last_name`),
  KEY `idx_email` (`email`),
  KEY `idx_client_department_id` (`client_department_id`),
  KEY `idx_reports_to_contact_id` (`reports_to_contact_id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_priority` (`priority`),
  KEY `idx_created_by_user_id` (`created_by_id`),
  KEY `idx_owner_user_id` (`owner_user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_deleted_at` (`deleted_at`),
  CONSTRAINT `fk_contacts_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_contacts_department` FOREIGN KEY (`client_department_id`) REFERENCES `client_departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_contacts_reports_to` FOREIGN KEY (`reports_to_contact_id`) REFERENCES `contacts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `alpha2` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ISO 3166-1 alpha-2 code (US, CA, GB)',
  `alpha3` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ISO 3166-1 alpha-3 code (USA, CAN, GBR)',
  `numeric` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ISO 3166-1 numeric code (840, 124, 826)',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Official country name',
  `common_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Common name if different from official',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Active status - disable instead of delete to preserve FKs',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alpha2` (`alpha2`),
  KEY `idx_alpha2` (`alpha2`),
  KEY `idx_alpha3` (`alpha3`),
  KEY `idx_enabled` (`enabled`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demo_products`
--

DROP TABLE IF EXISTS `demo_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `demo_products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `status_id` bigint NOT NULL DEFAULT '1',
  `category_id` bigint NOT NULL DEFAULT '1',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status_id` (`status_id`),
  KEY `idx_category_id` (`category_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demo_products`
--

LOCK TABLES `demo_products` WRITE;
/*!40000 ALTER TABLE `demo_products` DISABLE KEYS */;
INSERT INTO `demo_products` VALUES (1,'Wireless Mouse','Ergonomic wireless mouse with 2.4GHz connectivity',29.99,1,1,'2026-08-24 05:04:47.468','2026-08-24 05:04:47.468',NULL,NULL,NULL,NULL),(2,'Vintage T-Shirt','Classic cotton t-shirt with retro design',19.99,1,2,'2026-08-24 05:04:47.468','2026-08-24 05:04:47.468',NULL,NULL,NULL,NULL),(3,'JavaScript: The Good Parts','Essential guide to JavaScript programming',39.99,2,3,'2026-08-24 05:04:47.468','2026-08-24 05:04:47.468',NULL,NULL,NULL,NULL),(4,'Premium Coffee Beans','Single-origin Arabica beans from Colombia',24.99,1,4,'2026-08-24 05:04:47.468','2026-08-24 05:04:47.468',NULL,NULL,NULL,NULL),(5,'Gaming Laptop','High-performance laptop with RTX graphics',1299.99,3,1,'2026-08-24 05:04:47.468','2026-08-24 05:04:47.468',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `demo_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_queue`
--

DROP TABLE IF EXISTS `email_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_queue` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `to_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `template` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_data` json DEFAULT NULL,
  `category_id` bigint NOT NULL DEFAULT '2',
  `rendered_html` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status_id` bigint NOT NULL DEFAULT '1',
  `error` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `retry_count` bigint NOT NULL DEFAULT '0',
  `retry_at` timestamp(3) NULL DEFAULT NULL,
  `dev_original_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_at` timestamp(3) NULL DEFAULT NULL,
  `opened_at` timestamp(3) NULL DEFAULT NULL,
  `related_type` bigint DEFAULT NULL,
  `related_id` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_queue_site_id` (`site_id`),
  KEY `idx_email_queue_status_id` (`status_id`),
  KEY `idx_email_queue_category_id` (`category_id`),
  KEY `idx_email_queue_to_address` (`to_address`),
  KEY `idx_email_queue_created_at` (`created_at`),
  KEY `idx_email_queue_retry_at` (`retry_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `email_queue_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_queue`
--

LOCK TABLES `email_queue` WRITE;
/*!40000 ALTER TABLE `email_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_recipients`
--

DROP TABLE IF EXISTS `email_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_recipients` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_blocked_notification` tinyint(1) NOT NULL DEFAULT '0',
  `is_blocked_marketing` tinyint(1) NOT NULL DEFAULT '0',
  `is_blocked_all` tinyint(1) NOT NULL DEFAULT '0',
  `total_sent` bigint NOT NULL DEFAULT '0',
  `total_failed` bigint NOT NULL DEFAULT '0',
  `last_sent_at` timestamp(3) NULL DEFAULT NULL,
  `unsubscribed_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email_recipients_site_email` (`site_id`,`email`),
  KEY `idx_email_recipients_site_id` (`site_id`),
  KEY `idx_email_recipients_email` (`email`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `email_recipients_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_recipients`
--

LOCK TABLES `email_recipients` WRITE;
/*!40000 ALTER TABLE `email_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_addresses`
--

DROP TABLE IF EXISTS `ip_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_addresses` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ip_addresses_ip` (`ip_address`),
  KEY `idx_ip_addresses_country` (`country`),
  KEY `idx_ip_addresses_location` (`lat`,`lng`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_addresses`
--

LOCK TABLES `ip_addresses` WRITE;
/*!40000 ALTER TABLE `ip_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_users`
--

DROP TABLE IF EXISTS `login_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT '0',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `status_id` bigint NOT NULL DEFAULT '1',
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone_auto` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_login_users_email` (`email`),
  KEY `idx_login_users_is_activated` (`is_activated`),
  KEY `idx_login_users_is_verified` (`is_verified`),
  KEY `idx_login_users_status_id` (`status_id`),
  KEY `idx_login_users_created_at` (`created_at`),
  KEY `idx_login_users_updated_at` (`updated_at`),
  KEY `idx_login_users_last_login` (`last_login`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_login_users_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_users`
--

LOCK TABLES `login_users` WRITE;
/*!40000 ALTER TABLE `login_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `type_id` bigint NOT NULL,
  `entity_type` bigint DEFAULT NULL,
  `entity_id` bigint DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `read_at` timestamp(3) NULL DEFAULT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_site_user` (`site_id`,`user_id`),
  KEY `idx_notifications_user_unread` (`site_id`,`user_id`,`read_at`),
  KEY `idx_notifications_entity` (`entity_type`,`entity_id`),
  KEY `idx_notifications_expires` (`expires_at`),
  KEY `idx_notifications_type` (`type_id`),
  KEY `idx_notifications_created` (`created_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parties`
--

DROP TABLE IF EXISTS `parties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parties` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `type_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parties_site_id` (`site_id`),
  KEY `idx_parties_type_id` (`type_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `parties_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parties`
--

LOCK TABLES `parties` WRITE;
/*!40000 ALTER TABLE `parties` DISABLE KEYS */;
/*!40000 ALTER TABLE `parties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party_company_details`
--

DROP TABLE IF EXISTS `party_company_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `party_company_details` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `party_id` bigint NOT NULL,
  `legal_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_identifier` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_count` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_party_company_details_party_id` (`party_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `party_company_details_ibfk_1` FOREIGN KEY (`party_id`) REFERENCES `parties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party_company_details`
--

LOCK TABLES `party_company_details` WRITE;
/*!40000 ALTER TABLE `party_company_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_company_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party_person_details`
--

DROP TABLE IF EXISTS `party_person_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `party_person_details` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `party_id` bigint NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_party_person_details_party_id` (`party_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `party_person_details_ibfk_1` FOREIGN KEY (`party_id`) REFERENCES `parties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party_person_details`
--

LOCK TABLES `party_person_details` WRITE;
/*!40000 ALTER TABLE `party_person_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_person_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_invitations`
--

DROP TABLE IF EXISTS `portal_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_invitations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `invitation_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` bigint NOT NULL DEFAULT '1',
  `metadata` json DEFAULT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `used_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_portal_invitations_code` (`invitation_code`),
  KEY `idx_portal_invitations_site_id` (`site_id`),
  KEY `idx_portal_invitations_email` (`email`),
  KEY `idx_portal_invitations_site_email` (`site_id`,`email`),
  KEY `idx_portal_invitations_expires_at` (`expires_at`),
  KEY `idx_portal_invitations_used_at` (`used_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_portal_invitations_status` (`status_id`),
  CONSTRAINT `portal_invitations_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_invitations`
--

LOCK TABLES `portal_invitations` WRITE;
/*!40000 ALTER TABLE `portal_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_memberships`
--

DROP TABLE IF EXISTS `portal_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_memberships` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `portal_user_id` bigint NOT NULL,
  `client_id` bigint NOT NULL,
  `role_id` bigint NOT NULL DEFAULT '1',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_portal_memberships_user_client` (`portal_user_id`,`client_id`),
  KEY `idx_portal_memberships_site_id` (`site_id`),
  KEY `idx_portal_memberships_portal_user_id` (`portal_user_id`),
  KEY `idx_portal_memberships_client_id` (`client_id`),
  KEY `idx_portal_memberships_role_id` (`role_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `portal_memberships_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `portal_memberships_ibfk_2` FOREIGN KEY (`portal_user_id`) REFERENCES `portal_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `portal_memberships_ibfk_3` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_memberships`
--

LOCK TABLES `portal_memberships` WRITE;
/*!40000 ALTER TABLE `portal_memberships` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_notifications`
--

DROP TABLE IF EXISTS `portal_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `portal_user_id` bigint NOT NULL,
  `type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` bigint DEFAULT NULL,
  `subject_id` bigint DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `read_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_portal_notifications_site_id` (`site_id`),
  KEY `idx_portal_notifications_recipient` (`site_id`,`portal_user_id`,`created_at`),
  KEY `idx_portal_notifications_unread` (`site_id`,`portal_user_id`,`read_at`),
  KEY `idx_portal_notifications_type` (`type`),
  KEY `idx_portal_notifications_subject` (`subject_type`,`subject_id`),
  KEY `fk_portal_notifications_portal_user` (`portal_user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_portal_notifications_portal_user` FOREIGN KEY (`portal_user_id`) REFERENCES `portal_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_notifications`
--

LOCK TABLES `portal_notifications` WRITE;
/*!40000 ALTER TABLE `portal_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_password_resets`
--

DROP TABLE IF EXISTS `portal_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_password_resets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `portal_user_id` bigint NOT NULL,
  `token` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `used_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_portal_password_resets_token` (`token`),
  KEY `idx_portal_password_resets_site_id` (`site_id`),
  KEY `idx_portal_password_resets_portal_user_id` (`portal_user_id`),
  KEY `idx_portal_password_resets_expires_at` (`expires_at`),
  KEY `idx_portal_password_resets_used_at` (`used_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `portal_password_resets_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `portal_password_resets_ibfk_2` FOREIGN KEY (`portal_user_id`) REFERENCES `portal_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_password_resets`
--

LOCK TABLES `portal_password_resets` WRITE;
/*!40000 ALTER TABLE `portal_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_projects`
--

DROP TABLE IF EXISTS `portal_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_projects` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `client_id` bigint NOT NULL,
  `project_id` bigint NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_portal_projects_client_project` (`client_id`,`project_id`),
  KEY `idx_portal_projects_site_id` (`site_id`),
  KEY `idx_portal_projects_client_id` (`client_id`),
  KEY `idx_portal_projects_project_id` (`project_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `portal_projects_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `portal_projects_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `portal_projects_ibfk_3` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_projects`
--

LOCK TABLES `portal_projects` WRITE;
/*!40000 ALTER TABLE `portal_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_request_documents`
--

DROP TABLE IF EXISTS `portal_request_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_request_documents` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `thread_id` bigint NOT NULL,
  `message_id` bigint NOT NULL,
  `attachment_id` bigint NOT NULL,
  `requires_review` tinyint(1) NOT NULL DEFAULT '1',
  `review_status` bigint NOT NULL DEFAULT '1',
  `reject_reason` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `reviewed_by` bigint DEFAULT NULL,
  `reviewed_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prd_thread` (`thread_id`),
  KEY `idx_prd_message` (`message_id`),
  KEY `idx_prd_attachment` (`attachment_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_prd_message_id` FOREIGN KEY (`message_id`) REFERENCES `portal_request_messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prd_thread_id` FOREIGN KEY (`thread_id`) REFERENCES `portal_request_threads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_request_documents`
--

LOCK TABLES `portal_request_documents` WRITE;
/*!40000 ALTER TABLE `portal_request_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_request_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_request_events`
--

DROP TABLE IF EXISTS `portal_request_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_request_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `thread_id` bigint NOT NULL,
  `from_status` bigint DEFAULT NULL,
  `to_status` bigint NOT NULL,
  `actor_type` bigint DEFAULT NULL,
  `actor_id` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pre_thread` (`thread_id`,`created_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_pre_thread_id` FOREIGN KEY (`thread_id`) REFERENCES `portal_request_threads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_request_events`
--

LOCK TABLES `portal_request_events` WRITE;
/*!40000 ALTER TABLE `portal_request_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_request_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_request_messages`
--

DROP TABLE IF EXISTS `portal_request_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_request_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `thread_id` bigint NOT NULL,
  `author_type` bigint DEFAULT NULL,
  `author_id` bigint DEFAULT NULL,
  `body` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prm_thread` (`thread_id`,`created_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_prm_thread_id` FOREIGN KEY (`thread_id`) REFERENCES `portal_request_threads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_request_messages`
--

LOCK TABLES `portal_request_messages` WRITE;
/*!40000 ALTER TABLE `portal_request_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_request_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_request_threads`
--

DROP TABLE IF EXISTS `portal_request_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_request_threads` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `client_id` bigint NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` bigint NOT NULL DEFAULT '1',
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `last_activity_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prt_site_client` (`site_id`,`client_id`),
  KEY `idx_prt_status` (`site_id`,`status_id`),
  KEY `fk_prt_client_id` (`client_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_prt_client_id` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_request_threads`
--

LOCK TABLES `portal_request_threads` WRITE;
/*!40000 ALTER TABLE `portal_request_threads` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_request_threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_users`
--

DROP TABLE IF EXISTS `portal_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `contact_id` bigint DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `status_id` bigint NOT NULL DEFAULT '1',
  `metadata` json DEFAULT NULL,
  `last_login` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_portal_users_site_email` (`site_id`,`email`),
  KEY `idx_portal_users_site_id` (`site_id`),
  KEY `idx_portal_users_email` (`email`),
  KEY `idx_portal_users_status_id` (`status_id`),
  KEY `idx_portal_users_is_verified` (`is_verified`),
  KEY `idx_portal_users_created_at` (`created_at`),
  KEY `idx_portal_users_last_login` (`last_login`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_portal_users_contact_id` (`contact_id`),
  KEY `idx_portal_users_deleted_at` (`deleted_at`),
  CONSTRAINT `fk_portal_users_contact_id` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `portal_users_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_users`
--

LOCK TABLES `portal_users` WRITE;
/*!40000 ALTER TABLE `portal_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_contacts`
--

DROP TABLE IF EXISTS `project_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_contacts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `project_id` bigint NOT NULL,
  `contact_id` bigint NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_project_contacts` (`project_id`,`contact_id`),
  KEY `idx_project_contacts_site_id` (`site_id`),
  KEY `idx_project_contacts_project_id` (`project_id`),
  KEY `idx_project_contacts_contact_id` (`contact_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_project_contacts_contact` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_project_contacts_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_project_contacts_site` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_contacts`
--

LOCK TABLES `project_contacts` WRITE;
/*!40000 ALTER TABLE `project_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_users`
--

DROP TABLE IF EXISTS `project_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `project_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_project_users` (`project_id`,`user_id`),
  KEY `idx_project_users_site_id` (`site_id`),
  KEY `idx_project_users_project_id` (`project_id`),
  KEY `idx_project_users_user_id` (`user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_project_users_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_project_users_site` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_project_users_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_users`
--

LOCK TABLES `project_users` WRITE;
/*!40000 ALTER TABLE `project_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `client_id` bigint NOT NULL,
  `parent_project_id` bigint DEFAULT NULL,
  `client_department_id` bigint DEFAULT NULL,
  `status` bigint NOT NULL DEFAULT '1',
  `priority` bigint NOT NULL DEFAULT '2',
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `budget` decimal(15,2) DEFAULT NULL,
  `notes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `owner_user_id` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_client_department_id` (`client_department_id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_created_by` (`created_by_id`),
  KEY `idx_owner_user_id` (`owner_user_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_updated_at` (`updated_at`),
  KEY `idx_name` (`name`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_deleted_at` (`deleted_at`),
  KEY `idx_projects_parent_project_id` (`parent_project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `regions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ISO 3166-2 code (US-CA, CA-ON, GB-ENG)',
  `country_alpha2` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Foreign key to countries.alpha2',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Subdivision name (California, Ontario, England)',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Type: state, province, territory, country, etc.',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Active status - disable instead of delete',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_country_code` (`country_alpha2`,`code`),
  KEY `idx_country` (`country_alpha2`),
  KEY `idx_code` (`code`),
  KEY `idx_enabled` (`enabled`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_regions_country` FOREIGN KEY (`country_alpha2`) REFERENCES `countries` (`alpha2`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions`
--

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shared_items`
--

DROP TABLE IF EXISTS `shared_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shared_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `shared_by` bigint NOT NULL,
  `contact_id` bigint NOT NULL,
  `item_type` bigint NOT NULL,
  `item_id` bigint NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `expires_at` timestamp(3) NULL DEFAULT NULL,
  `accessed_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_shared_items_token` (`token`),
  KEY `idx_shared_items_site_id` (`site_id`),
  KEY `idx_shared_items_shared_by` (`shared_by`),
  KEY `idx_shared_items_contact_id` (`contact_id`),
  KEY `idx_shared_items_item_type_id` (`item_type`,`item_id`),
  KEY `idx_shared_items_expires_at` (`expires_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `shared_items_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shared_items_ibfk_2` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shared_items`
--

LOCK TABLES `shared_items` WRITE;
/*!40000 ALTER TABLE `shared_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `shared_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'America/Chicago',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sites_slug` (`slug`),
  KEY `idx_sites_is_enabled` (`is_enabled`),
  KEY `idx_sites_deleted_at` (`deleted_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (0,'default','Default','America/Chicago',1,NULL,'2026-08-24 05:05:47.686','2026-08-24 05:05:47.686',NULL,NULL,NULL,NULL,NULL,NULL),(1,'test','Test Site','America/Chicago',1,NULL,'2026-08-24 05:05:02.768','2026-08-24 05:05:02.768',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_queue`
--

DROP TABLE IF EXISTS `sms_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_queue` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `to_number` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint NOT NULL DEFAULT '2',
  `status_id` bigint NOT NULL DEFAULT '1',
  `error` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `retry_count` bigint NOT NULL DEFAULT '0',
  `retry_at` timestamp(3) NULL DEFAULT NULL,
  `dev_original_to` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_at` timestamp(3) NULL DEFAULT NULL,
  `related_type` bigint DEFAULT NULL,
  `related_id` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sms_queue_site_id` (`site_id`),
  KEY `idx_sms_queue_status_id` (`status_id`),
  KEY `idx_sms_queue_category_id` (`category_id`),
  KEY `idx_sms_queue_to_number` (`to_number`),
  KEY `idx_sms_queue_created_at` (`created_at`),
  KEY `idx_sms_queue_retry_at` (`retry_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `sms_queue_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_queue`
--

LOCK TABLES `sms_queue` WRITE;
/*!40000 ALTER TABLE `sms_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_recipients`
--

DROP TABLE IF EXISTS `sms_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_recipients` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `number` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_blocked_notification` tinyint(1) NOT NULL DEFAULT '0',
  `is_blocked_marketing` tinyint(1) NOT NULL DEFAULT '0',
  `is_blocked_all` tinyint(1) NOT NULL DEFAULT '0',
  `total_sent` bigint NOT NULL DEFAULT '0',
  `total_failed` bigint NOT NULL DEFAULT '0',
  `last_sent_at` timestamp(3) NULL DEFAULT NULL,
  `unsubscribed_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sms_recipients_site_number` (`site_id`,`number`),
  KEY `idx_sms_recipients_site_id` (`site_id`),
  KEY `idx_sms_recipients_number` (`number`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `sms_recipients_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_recipients`
--

LOCK TABLES `sms_recipients` WRITE;
/*!40000 ALTER TABLE `sms_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `taskable_type` bigint DEFAULT NULL,
  `taskable_id` bigint DEFAULT NULL,
  `project_id` bigint DEFAULT NULL,
  `status` bigint NOT NULL DEFAULT '1',
  `priority` bigint NOT NULL DEFAULT '2',
  `due_date` date DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `assigned_to_user_id` bigint DEFAULT NULL,
  `notes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `hour_estimate` decimal(8,2) DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_assigned_to_user_id` (`assigned_to_user_id`),
  KEY `idx_created_by` (`created_by_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_updated_at` (`updated_at`),
  KEY `idx_title` (`title`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_deleted_at` (`deleted_at`),
  KEY `idx_taskable` (`taskable_type`,`taskable_id`),
  KEY `idx_tasks_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_members`
--

DROP TABLE IF EXISTS `user_group_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_members` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_group_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_group_members_unique` (`user_group_id`,`user_id`),
  KEY `user_group_members_group_id_idx` (`user_group_id`),
  KEY `user_group_members_user_id_idx` (`user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `user_group_members_group_fk` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_group_members_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_members`
--

LOCK TABLES `user_group_members` WRITE;
/*!40000 ALTER TABLE `user_group_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_group_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `deletion_protection` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_groups_site_id_idx` (`site_id`),
  KEY `user_groups_name_idx` (`name`),
  KEY `user_groups_deleted_at_idx` (`deleted_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_invites`
--

DROP TABLE IF EXISTS `user_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_invites` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `site_id` bigint NOT NULL,
  `invite_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_invites_code` (`invite_code`),
  KEY `idx_user_invites_user_id` (`user_id`),
  KEY `idx_user_invites_site_id` (`site_id`),
  KEY `idx_user_invites_expires_at` (`expires_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_user_invites_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_invites_ibfk_2` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_invites`
--

LOCK TABLES `user_invites` WRITE;
/*!40000 ALTER TABLE `user_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` bigint NOT NULL,
  `is_grant` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_permission` (`user_id`,`permission_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_permission_id` (`permission_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_user_permissions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profiles`
--

DROP TABLE IF EXISTS `user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profiles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  CONSTRAINT `fk_user_profiles_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profiles`
--

LOCK TABLES `user_profiles` WRITE;
/*!40000 ALTER TABLE `user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_verifications`
--

DROP TABLE IF EXISTS `user_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_verifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `verification_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `verification_type_id` bigint NOT NULL,
  `verified_at` timestamp(3) NULL DEFAULT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_verifications_email` (`email`),
  KEY `idx_user_verifications_code` (`verification_code`),
  KEY `idx_user_verifications_type` (`verification_type_id`),
  KEY `idx_user_verifications_expires_at` (`expires_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_verifications`
--

LOCK TABLES `user_verifications` WRITE;
/*!40000 ALTER TABLE `user_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `login_user_id` bigint DEFAULT NULL,
  `site_id` bigint NOT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp(3) NULL DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `created_by_id` bigint DEFAULT NULL,
  `created_by_type` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `updated_by_type` bigint DEFAULT NULL,
  `deleted_by_id` bigint DEFAULT NULL,
  `deleted_by_type` bigint DEFAULT NULL,
  `invite_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invite_accepted_at` timestamp(3) NULL DEFAULT NULL,
  `invite_expires_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_login_user_site` (`login_user_id`,`site_id`),
  UNIQUE KEY `uk_users_invite_code` (`invite_code`),
  KEY `idx_site_users_site_id` (`site_id`),
  KEY `idx_site_users_role_id` (`role_id`),
  KEY `idx_site_users_is_enabled` (`is_enabled`),
  KEY `idx_site_users_deleted_at` (`deleted_at`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `idx_users_phone` (`phone`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_invite_accepted_at` (`invite_accepted_at`),
  KEY `idx_users_invite_expires_at` (`invite_expires_at`),
  CONSTRAINT `fk_users_login_user_id` FOREIGN KEY (`login_user_id`) REFERENCES `login_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_users_site_id` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-24  6:16:22
